Synthetic example prompt for the ASFA command-line demonstration.
